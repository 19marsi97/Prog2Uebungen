package JavaDoc;

public class javaDoc {
	
	// Diese Methode soll erg�nzt werden

	public static Integer[] manipulateArray(Integer[] arr1) {
		
		return null;
	}
	
	
	
	public static void main(String[] args) {
		Integer[] arr1 = { 5, 7, 19, 4, 2, 0, 127, 344, 721, 80 };
		Integer[] solutionArray = manipulateArray(arr1);

		try {
			System.out.println("Manipuliertes Array: ");
			for (int i : solutionArray) {
				System.out.print(i + ", ");
			}
		} catch (NullPointerException e) {
			System.out.println("Die Methode manipulateArray gibt \"null\" zur�ck");
		}
	}
}
