package JavaDoc;

import java.util.*;

public class JavaDocLoesung {

	/**
	 * This method will manipulate an integer array the following way: First, it
	 * will delete all odd numbers. Secondly, it will sort the remaining numbers in
	 * ascending order. The sorting is performed by the corresponding method in the
	 * java class "Arrays". The returned array will not contain any "null" elements.
	 * 
	 * @param arr1
	 *            - Integer array which shall be manipulated.
	 * @return - Integer array with the result of the manipulation.
	 */
	public static Integer[] manipulateArray(Integer[] arr1) throws NullPointerException{
		List<Integer> localArrayList = Arrays.asList(arr1);
		List<Integer> helpList = new ArrayList<>();
		for(Integer i : localArrayList) {
			if(i % 2 == 0)
				helpList.add(i);
		}
		Integer[] returnArray = new Integer[helpList.size()];
		helpList.toArray(returnArray);
		Arrays.sort(returnArray);
		return returnArray;
	}

	public static void main(String[] args) {
		Integer[] arr1 = { 5, 7, 19, 4, 2, 0, 127, 344, 721, 80 };
		Integer[] solutionArray = manipulateArray(arr1);

		try {
			System.out.println("Manipuliertes Array: ");
			for (int i : solutionArray) {
				System.out.print(i + ", ");
			}
		} catch (NullPointerException e) {
			System.out.println("Die Methode manipulateArray gibt \"null\" zur�ck");
		}
	}
}