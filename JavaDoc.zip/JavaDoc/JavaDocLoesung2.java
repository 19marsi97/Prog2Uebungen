package JavaDoc;

import java.util.*;

public class JavaDocLoesung2 {

	/**
	 * This method will manipulate an integer array the following way: First, it
	 * will delete all odd numbers. Secondly, it will sort the remaining numbers in
	 * ascending order. The sorting is performed by the corresponding method in the
	 * java class "Arrays". The returned array will not contain any "null" elements.
	 * 
	 * @param arr1
	 *            - Integer array which shall be manipulated.
	 * @return - Integer list with the result of the manipulation.
	 */
	public static List<Integer> manipulateArray(Integer[] arr1) throws NullPointerException{
		if(arr1.equals(null)) {
			throw new NullPointerException();
		}
		List<Integer> localList = new ArrayList<>(Arrays.asList(arr1));
				localList.removeIf((Integer i) -> {return i % 2 != 0;});
		localList.sort((a, b) -> Integer.compare(a, b));
		return localList;
	}

	public static void main(String[] args) {
		Integer[] arr1 = { 5, 7, 19, 4, 2, 0, 127, 344, 721, 80 };
		List<Integer> solutionList = manipulateArray(arr1);
		
		try {
			System.out.println("Manipuliertes Array: ");
			solutionList.forEach(i -> System.out.print(i + ", "));
		} catch (NullPointerException e) {
			System.out.println("Die Methode manipulateArray gibt \"null\" zur�ck");
		}
	}
}