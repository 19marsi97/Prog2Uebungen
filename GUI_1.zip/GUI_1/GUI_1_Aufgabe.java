package GUI_1;

import javax.swing.*;
import java.awt.*;

public class GUI_1_Aufgabe extends JFrame{
	
	public GUI_1_Aufgabe() {
		
	}
	
	
	
	public static void main(String[] args) {
		GUI_1_Aufgabe frame = new GUI_1_Aufgabe();
		
	}
}