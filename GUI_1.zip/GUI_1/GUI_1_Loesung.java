package GUI_1;

import javax.swing.*;
import java.awt.*;

public class GUI_1_Loesung extends JFrame {
	Container c;
	JLabel[] labels = new JLabel[9];

	public GUI_1_Loesung() {
		c = getContentPane();
		c.setLayout(new BorderLayout());
		JPanel supportPanel = new JPanel(), mainPanel = new JPanel();
		supportPanel.setLayout(new BorderLayout());
		mainPanel.setLayout(new GridLayout(3, 3));
		mainPanel.setBackground(Color.GRAY);
		
		for(Integer i = 1; i <= 9; i++)
			labels[i-1] = new JLabel(i.toString());
		
		
		for(JLabel lab : labels) {
			lab.setHorizontalAlignment(SwingConstants.CENTER);
			lab.setVerticalAlignment(SwingConstants.CENTER);
			lab.setBorder(BorderFactory.createLineBorder(Color.black));
			mainPanel.add(lab);
		}
		
		JButton button = new JButton("Hello World");
		supportPanel.add(mainPanel);
		supportPanel.add(button, BorderLayout.SOUTH);
		c.add(supportPanel);
		
		
		JPanel space1 = new JPanel(), space2 = new JPanel(), space3 = new JPanel(), space4 = new JPanel();
		space1.setBackground(Color.DARK_GRAY);
		space2.setBackground(Color.DARK_GRAY);
		space3.setBackground(Color.DARK_GRAY);
		space4.setBackground(Color.DARK_GRAY);
		
		
		c.add(space1, BorderLayout.SOUTH);
		c.add(space2, BorderLayout.NORTH);
		c.add(space3, BorderLayout.EAST);
		c.add(space4, BorderLayout.WEST);
	}

	public static void main(String[] args) {
		GUI_1_Loesung frame = new GUI_1_Loesung();
		frame.setTitle("Loesung");
		frame.getContentPane().setBackground(Color.GREEN);
		frame.setSize(500, 500);
		frame.setLocation(150, 150);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}