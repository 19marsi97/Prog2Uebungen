package GUI_2;

import java.awt.*;
import javax.swing.*;

public class Aufgabe extends JFrame {

	public Aufgabe() {

	}

	public static void main(String[] args) {
		Aufgabe localObject = new Aufgabe();
		localObject.setTitle("GUI_2");
		localObject.setSize(500, 500);
		localObject.setLocation(100, 100);
		localObject.setVisible(true);
		localObject.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}