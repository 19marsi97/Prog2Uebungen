package GUI_2;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Loesung extends JFrame {
	Container c;

	public Loesung() {
		c = getContentPane();
		c.setLayout(new GridLayout(2, 1));
		JPanel upperHalf = new JPanel(), lowerHalf = new JPanel(), upperLeft = new JPanel(), upperRight = new JPanel();
		upperHalf.setLayout(new GridLayout(1, 2));
		upperLeft.setLayout(new GridLayout(5, 1));

		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int random = (int) (Math.random() * 255);
				lowerHalf.setBackground(new Color(random - 10, random % 20, random));
			}
		});

		JRadioButton buttonRed = new JRadioButton("Red"), buttonBlue = new JRadioButton("Blue"),
				buttonGreen = new JRadioButton("Green");

		JRadioButton[] buttonArray = { buttonRed, buttonBlue, buttonGreen };

		buttonRed.addActionListener((e) -> {
			lowerHalf.setBackground(Color.RED);
		});
		buttonBlue.addActionListener((e) -> {
			lowerHalf.setBackground(Color.BLUE);
		});
		buttonGreen.addActionListener((e) -> {
			lowerHalf.setBackground(Color.GREEN);
		});

		ButtonGroup group = new ButtonGroup();

		for (JRadioButton but : buttonArray) {
			group.add(but);
			but.setVerticalAlignment(SwingConstants.CENTER);
			upperLeft.add(but);
		}

		upperLeft.setBorder(new EmptyBorder(10, 10, 10, 10));

		JButton reset = new JButton("Reset");
		reset.addActionListener(e -> {
			lowerHalf.setBackground(Color.WHITE);
		});
		upperRight.setBorder(new EmptyBorder(50, 0, 0, 0));

		upperRight.add(reset);

		upperHalf.add(upperLeft);
		upperHalf.add(upperRight);

		c.add(upperHalf);
		c.add(lowerHalf);

	}

	public static void main(String[] args) {
		Loesung localObject = new Loesung();
		localObject.setTitle("GUI_2");
		localObject.setSize(500, 500);
		localObject.setLocation(100, 100);
		localObject.setVisible(true);
		localObject.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}