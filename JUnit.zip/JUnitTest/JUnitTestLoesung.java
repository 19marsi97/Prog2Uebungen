package JUnitTest;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class JUnitTestLoesung {


	Double[] arr1 = { 1.0, 2.0, 3.0 };
	Double[] arr2 = { 2.0, 3.0, 4.0, 5.0 };

	@Test
	public void testJoinForArrayLength() {
		int newLength = arr1.length + arr2.length;
		assertEquals(newLength, ArrayVerarbeitung.joinArray(arr1, arr2).length);
	}

	@Test(expected = NullPointerException.class)
	public void joinThrowsException() throws NullPointerException {
		ArrayVerarbeitung.joinArray(arr1, null);
	}
	
	@Test(expected = NullPointerException.class)
	public void intersectThrowsException() throws NullPointerException {
		ArrayVerarbeitung.intersectArrays(arr1, null);
	}
	
	@Test
	public void intersectCheckValues() {
		Double[] result = {2.0, 3.0};
		assertArrayEquals(result, ArrayVerarbeitung.intersectArrays(arr1, arr2));
	}
}
