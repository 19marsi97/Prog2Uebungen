package JUnitTest;

import static org.junit.Assert.*;
import org.junit.Test;

public class JUnitTest {

	// Hier ist Platz f�r die JUnit Tests. F�r Tipps einfach in die L�sungsdatei schauen.
	
	
	
}
