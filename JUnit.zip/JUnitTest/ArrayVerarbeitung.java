package JUnitTest;

import java.util.*;

public class ArrayVerarbeitung {

	/**
	 * This method shall be able to join two arrays which contain numbers
	 * The returning array will contain the numbers of the first array followed by all entries of the second array
	 * No values are skipped.
	 */
	public static Number[] joinArray(Number[] arr1, Number[] arr2) throws NullPointerException{
		if(arr1.equals(null) || arr2.equals(null)) {
			throw new NullPointerException();
		}
		Number[] fullArray = new Number[arr1.length + arr2.length];
		for(int i = 0; i < arr1.length; i++) {
			fullArray[i] = arr1[i];
		}
		
		for(int i = 0, j = arr1.length; i < arr2.length; i++, j++) {
			fullArray[j] = arr2[i];
		}
		
		return fullArray;
	}
	
	/**
	 * Returns only the values which appear in both arrays
	 * @param arr1 
	 * @param arr2
	 * @return
	 * @throws NullPointerException
	 */
	public static Double[] intersectArrays(Double[] arr1, Double[] arr2) throws NullPointerException{
		if(arr1.equals(null) || arr2.equals(null)) {
			throw new NullPointerException();
		}
		List<Double> localList = new ArrayList<>();
		
		List<Double> shorterArray = arr1.length <= arr2.length ? Arrays.asList(arr1) :  Arrays.asList(arr2);
		List<Double> secondArray = shorterArray.equals(Arrays.asList(arr1)) ?  Arrays.asList(arr2) :  Arrays.asList(arr1);
		
		for(Double d : shorterArray) {
			if(secondArray.contains(d)) {
				localList.add(d);
			}
		}
		Double[] returnArray = new Double[localList.size()];
		return localList.toArray(returnArray);
	}
	
	/**
	 * Main class to test methods with values
	 * @param args
	 */
	public static void main(String[] args) {
		Integer[] arr1 = {1, 2, 3};
		Double[] arr2 = {0.0, 1.0, 5.0};
		Double[] arr3 = {0.0, 1.5, 5.0, 7.3};
		
		Number[] joinArray = joinArray(arr1, arr2);
		System.out.println("Join Arrays:");
		for(Number n : joinArray) {
			System.out.print(n + ", ");
		}
		System.out.println("\n");
		
		System.out.println("Intersect Arrays:");
		Double[] intersectArray = intersectArrays(arr2, arr3);
		for(Double d : intersectArray) {
			System.out.print(d + ", ");
		}
	}
}
